package coreservices;

public interface Validator{

	Boolean validate(String...input);

}