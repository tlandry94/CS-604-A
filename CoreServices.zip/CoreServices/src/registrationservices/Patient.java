package registrationservices;

public class Patient extends User {
    public Patient(String firstNameInput, String lastNameInput, String emailInput, String passwordInput){
        super(firstNameInput, lastNameInput, emailInput, passwordInput);
    }//end constructor
    
}